# HW 1

Name: Henan Mu

NUID: 002783324

## Requirements

* JDK version 18
* Tomcat version 10

## Usage

* Part 2, go to http://localhost:8080/Hw1Part2/
* Part 3, go to http://localhost:8080/Hw1Part3/
* Part 4, go to http://localhost:8080/Hw1Part4/
* Part 5, go to http://localhost:8080/Hw1Part5/

